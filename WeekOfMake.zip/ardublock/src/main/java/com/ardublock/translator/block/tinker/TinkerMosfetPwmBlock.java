package com.ardublock.translator.block.tinker;

import com.ardublock.translator.Translator;

public class TinkerMosfetPwmBlock extends AbstractTinkerWriteAnalogBlock
{

	public TinkerMosfetPwmBlock(Long blockId, Translator translator, String codePrefix, String codeSuffix, String label)
	{
		super(blockId, translator, codePrefix, codeSuffix, label);
	}

}
