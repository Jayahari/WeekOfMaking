package com.ardublock.core.exception;

public class ArdublockException extends Exception //RuntimeException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1006562884406802985L;

}
