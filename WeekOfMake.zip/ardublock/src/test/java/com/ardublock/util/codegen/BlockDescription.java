package com.ardublock.util.codegen;

public class BlockDescription
{
	private String blockGenusName;
	private String blockImagePath;
	private String blockShowName;
	private String blockDescription;
	private String blockType;
	private String blockColor;
	public String getBlockGenusName() {
		return blockGenusName;
	}
	public void setBlockGenusName(String blockGenusName) {
		this.blockGenusName = blockGenusName;
	}
	public String getBlockImagePath() {
		return blockImagePath;
	}
	public void setBlockImagePath(String blockImagePath) {
		this.blockImagePath = blockImagePath;
	}
	public String getBlockShowName() {
		return blockShowName;
	}
	public void setBlockShowName(String blockShowName) {
		this.blockShowName = blockShowName;
	}
	public String getBlockDescription() {
		return blockDescription;
	}
	public void setBlockDescription(String blockDescription) {
		this.blockDescription = blockDescription;
	}
	public String getBlockType() {
		return blockType;
	}
	public void setBlockType(String blockType) {
		this.blockType = blockType;
	}
	public String getBlockColor() {
		return blockColor;
	}
	public void setBlockColor(String blockColor) {
		this.blockColor = blockColor;
	}
	
}
